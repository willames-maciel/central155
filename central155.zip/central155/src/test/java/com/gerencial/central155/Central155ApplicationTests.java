package com.gerencial.central155;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Central155ApplicationTests {

	@Test
	void contextLoads() {
	}

}
